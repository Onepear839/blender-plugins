bl_info = {
    "name": "Droplet Generator",
    "author": "ibotpl",
    "version": (2, 1, 1),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > Dropletgen",
    "description": "Adds Droplets to the selected object",
    "warning": "",
    "wiki_url": "",
    "category": "Object"
}

import os
import bpy

class AddDropletsPanel(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Droplet Generator"
    bl_idname = "VIEW3D_PT_add_droplets"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Dropletgen"

    def draw(self, context):
        layout = self.layout
        selected_objs = context.selected_objects
        if selected_objs:
            layout.operator("object.add_droplets_operator")
            layout.operator("object.add_custom_droplet_operator")
        else:
            layout.label(text="Please select an object")

class AddDropletsOperator(bpy.types.Operator):
    """Add droplets to selected object"""
    bl_idname = "object.add_droplets_operator"
    bl_label = "Add Droplets"
    bl_options = {"REGISTER", "UNDO"}
    
    def execute(self, context):
        node_tree_name = "DropletGenerator2_1"
        node_tree_file = os.path.join(os.path.dirname(__file__), "dropletgen_v2_1_1.blend")

        try:
            if node_tree_name not in bpy.data.node_groups:
                with bpy.data.libraries.load(node_tree_file) as (data_from, data_to):
                    data_to.node_groups = [name for name in data_from.node_groups if name == node_tree_name]

            selected_objs = context.selected_objects
            for obj in selected_objs:
                if obj.type == 'MESH':
                    droplets_modifier = next((mod for mod in obj.modifiers if mod.type == 'NODES' and mod.name == "Droplets"), None)
                    
                    if not droplets_modifier:
                        droplets_modifier = obj.modifiers.new(name="Droplets", type='NODES')
                    
                    droplets_modifier.node_group = bpy.data.node_groups[node_tree_name]
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        return {'FINISHED'}
        
class AddCustomDropletOperator(bpy.types.Operator):
    """Draw a custom droplet. Select it under the 'Custom Curve' input"""
    bl_idname = "object.add_custom_droplet_operator"
    bl_label = "Draw Custom Droplet"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        coll = obj.users_collection[0]

        new_curve_data = bpy.data.curves.new('CustomDroplet', 'CURVE')
        new_curve = bpy.data.objects.new('CustomDroplet', new_curve_data)
        bpy.context.scene.collection.objects.link(new_curve)

        bpy.ops.object.select_all(action='DESELECT')
        new_curve.select_set(True)
        bpy.context.view_layer.objects.active = new_curve
        bpy.ops.object.mode_set(mode='EDIT')

        bpy.ops.curve.select_all(action='SELECT')
        bpy.ops.curve.delete(type='VERT')
        new_curve.data.dimensions = '3D'

        bpy.ops.wm.tool_set_by_id(name="builtin.draw")
        bpy.data.scenes["Scene"].tool_settings.curve_paint_settings.depth_mode = 'SURFACE'

        return {'FINISHED'}

classes = [
    AddDropletsPanel,
    AddDropletsOperator,
    AddCustomDropletOperator
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
