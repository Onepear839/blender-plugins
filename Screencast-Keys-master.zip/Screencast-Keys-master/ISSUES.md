# Bug Report / Feature Request / Disscussions

If you want to report problem or request feature, please make issues.

https://github.com/nutti/Screencast-Keys/issues

You can discuss Screencast Keys at other places.
See the link below for further details.

* [Blender Artist](https://blenderartists.org/t/screencast-keys/1367219)
